function register(data){

    return FontFace

}

function login(data){

    return dd
}

module.exports = {
    register
};